# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class SelamatdesignsItem(scrapy.Item):

    Category = scrapy.Field()
    Product_Title = scrapy.Field()
    SKU = scrapy.Field()
    Description  = scrapy.Field()
    MSRP = scrapy.Field()
    Status = scrapy.Field()
    Material = scrapy.Field()

    w = scrapy.Field()
    d = scrapy.Field()
    h = scrapy.Field()

    Indoor_Outdoor = scrapy.Field()
    Product_Weight = scrapy.Field()
    Shipping_Method = scrapy.Field()

    Image1URL = scrapy.Field()
    Image2URL = scrapy.Field()
    Image3URL = scrapy.Field()
    Image4URL = scrapy.Field()
    Image5URL = scrapy.Field()
    Image6URL = scrapy.Field()
    Image7URL = scrapy.Field()
    Image8URL = scrapy.Field()
    Image9URL = scrapy.Field()
    Image10URL = scrapy.Field()

    pass
