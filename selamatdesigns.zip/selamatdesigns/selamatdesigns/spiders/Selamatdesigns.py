from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import SelamatdesignsItem
import re

class SelamatdesignsSpider(CrawlSpider):

    name = "selamatdesigns"
    
    Main_link = "https://selamatdesigns.trade/"

    #start_urls = ["https://selamatdesigns.trade/categories/316455/storage-_amp_-shelving/products/fbsh6d-nv/shanghai-6_dash_drawer-dresser-in-navy"]

    def __init__(self, config_file = None, *args, **kwargs):                    
        super(SelamatdesignsSpider, self).__init__(*args, **kwargs)   

        file = open("input.txt","r")

        links = []

        for link in file.readlines():
            links.append(link.replace("\n",""))

        self._url_list = links

        file.close()                                                             

    def start_requests(self):    

        for url in self._url_list:                                              
            yield Request(url = url, callback = self.cat_page)
            #return
   
    def cat_page(self, response):

        for next_page in response.css("#productsContainer .text-center.columns"):

            next_page_link = next_page.css(".item a::attr(href)").extract_first()

            yield Request(url= self.Main_link + next_page_link,callback=self.product_page)
            #return

    def product_page(self,response):

        product = SelamatdesignsItem()

        product["Category"]  = response.css("#view li:nth-child(3) a::text").extract_first()

        product["Product_Title"]   = response.css("#product-header-row h1::text").extract_first()

        product["SKU"]   = response.css("#product-header-row+ p::text").extract_first()

        product["Description"]   = response.css("#product p:nth-child(3)").extract_first()

        left=  response.css("#product p~ p+ p > strong::text").extract()

        temp_right = response.css("#product p~ p+ p::text").extract()

        right =  []

        for temp in temp_right:

            if not "\n" in temp:
                right.append(temp)


        for index,temp in enumerate(left):

            if "MSRP:" in temp:
                product["MSRP"] = right[index]

            if "Status:" in temp:
                product["Status"] = right[index]

            if "Material:" in temp:
                product["Material"] = right[index]

            if "Dimensions" in temp:

                #right[index] = right[index].replace("x","")
                
                save = right[index].split("x")

                try:
                    product["w"] = save[0]
                except:
                    pass

                try:
                    product["d"] = save[1]
                except:
                    pass

                try:
                    product["h"] = save[2]
                except:
                    pass
                

            if "Indoor/Outdoor:" in temp:
                product["Indoor_Outdoor"] = right[index]

            if "Product Weight:" in temp:
                product["Product_Weight"] = right[index]
            
            if "Shipping Method:" in temp:
                product["Shipping_Method"] = right[index]

        images = response.css("#main-slideshow img::attr(src)").extract()
        
        for index,img in enumerate(images):

            product[f"Image{index + 1}URL"] = img


        yield product 